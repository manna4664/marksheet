
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, FileText, GraduationCap, Download } from "lucide-react";
import StudentManagement from "@/components/StudentManagement";
import MarksEntry from "@/components/MarksEntry";
import MarksheetGenerator from "@/components/MarksheetGenerator";

const Index = () => {
  const [activeTab, setActiveTab] = useState("dashboard");

  const renderContent = () => {
    switch (activeTab) {
      case "students":
        return <StudentManagement />;
      case "marks":
        return <MarksEntry />;
      case "marksheets":
        return <MarksheetGenerator />;
      default:
        return (
          <div className="space-y-6">
            <div className="text-center py-8">
              <h1 className="text-4xl font-bold text-blue-800 mb-4">
                Self Confidence Academy
              </h1>
              <p className="text-lg text-gray-600 mb-8">
                School Management System
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab("students")}>
                <CardHeader className="text-center">
                  <Users className="mx-auto h-12 w-12 text-blue-600 mb-2" />
                  <CardTitle>Student Management</CardTitle>
                  <CardDescription>Add and manage student details</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full">Manage Students</Button>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab("marks")}>
                <CardHeader className="text-center">
                  <GraduationCap className="mx-auto h-12 w-12 text-green-600 mb-2" />
                  <CardTitle>Marks Entry</CardTitle>
                  <CardDescription>Enter marks for subjects</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full">Enter Marks</Button>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab("marksheets")}>
                <CardHeader className="text-center">
                  <Download className="mx-auto h-12 w-12 text-purple-600 mb-2" />
                  <CardTitle>Marksheet Generator</CardTitle>
                  <CardDescription>Generate and download marksheets</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full">Generate Marksheets</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-blue-800">Self Confidence Academy</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant={activeTab === "dashboard" ? "default" : "ghost"}
                onClick={() => setActiveTab("dashboard")}
              >
                Dashboard
              </Button>
              <Button
                variant={activeTab === "students" ? "default" : "ghost"}
                onClick={() => setActiveTab("students")}
              >
                Students
              </Button>
              <Button
                variant={activeTab === "marks" ? "default" : "ghost"}
                onClick={() => setActiveTab("marks")}
              >
                Marks
              </Button>
              <Button
                variant={activeTab === "marksheets" ? "default" : "ghost"}
                onClick={() => setActiveTab("marksheets")}
              >
                Marksheets
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {renderContent()}
      </main>
    </div>
  );
};

export default Index;
