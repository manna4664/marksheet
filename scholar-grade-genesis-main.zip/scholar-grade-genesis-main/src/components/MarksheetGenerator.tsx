import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Download, Eye } from "lucide-react";

interface Student {
  id: string;
  name: string;
  father_name: string;
  mother_name: string;
  date_of_birth: string;
  class_name: string;
  scholar_number: string;
  roll_number: string;
}

interface MarksheetData {
  student: Student;
  marks: Array<{
    subject_name: string;
    max_marks: number;
    obtained_marks: number;
    grade: string;
    percentage: number;
    category: string;
  }>;
  summary: {
    total_marks: number;
    total_max_marks: number;
    overall_percentage: number;
    overall_grade: string;
    academic_year: string;
  };
}

const MarksheetGenerator = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [marksheetData, setMarksheetData] = useState<MarksheetData | null>(null);
  const [academicYear, setAcademicYear] = useState("2024-25");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const { data, error } = await supabase
        .from("students")
        .select("*")
        .order("class_name", { ascending: true });

      if (error) throw error;
      setStudents(data || []);
    } catch (error) {
      console.error("Error fetching students:", error);
      toast({
        title: "Error",
        description: "Failed to fetch students",
        variant: "destructive",
      });
    }
  };

  const getRemarksByGrade = (grade: string) => {
    switch (grade) {
      case 'A': return 'Excellent';
      case 'B': return 'Good';
      case 'C': return 'Satisfactory';
      case 'D': return 'Needs Improvement';
      case 'E': return 'Poor';
      default: return 'Not Graded';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const generateMarksheet = async () => {
    if (!selectedStudent) {
      toast({
        title: "Error",
        description: "Please select a student",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.rpc('generate_marksheet_data', {
        student_uuid: selectedStudent.id,
        academic_year_param: academicYear
      });

      if (error) throw error;
      
      // Type cast the JSON response to our expected interface
      const typedData = data as unknown as MarksheetData;
      
      if (!typedData.marks || typedData.marks.length === 0) {
        toast({
          title: "No Data",
          description: "No marks found for this student",
          variant: "destructive",
        });
        setMarksheetData(null);
        return;
      }

      // Calculate totals for core subjects only
      const coreSubjects = typedData.marks.filter(mark => mark.category === 'Core');
      const totalCoreMarks = coreSubjects.reduce((sum, mark) => sum + mark.obtained_marks, 0);
      const totalCoreMaxMarks = coreSubjects.reduce((sum, mark) => sum + mark.max_marks, 0);
      const corePercentage = totalCoreMaxMarks > 0 ? (totalCoreMarks / totalCoreMaxMarks) * 100 : 0;
      
      // Calculate grade based on core subjects only
      let coreGrade = 'E';
      if (corePercentage >= 86) coreGrade = 'A';
      else if (corePercentage >= 71) coreGrade = 'B';
      else if (corePercentage >= 51) coreGrade = 'C';
      else if (corePercentage >= 31) coreGrade = 'D';

      // Update the summary with core subjects calculation
      const updatedData = {
        ...typedData,
        summary: {
          ...typedData.summary,
          total_marks: totalCoreMarks,
          total_max_marks: totalCoreMaxMarks,
          overall_percentage: corePercentage,
          overall_grade: coreGrade
        }
      };

      setMarksheetData(updatedData);
      
      // Save marksheet record
      await supabase.from("marksheets").upsert({
        student_id: selectedStudent.id,
        academic_year: academicYear,
        total_marks: totalCoreMarks,
        total_max_marks: totalCoreMaxMarks,
        overall_percentage: corePercentage,
        overall_grade: coreGrade
      });

      toast({
        title: "Success",
        description: "Marksheet generated successfully",
      });
    } catch (error) {
      console.error("Error generating marksheet:", error);
      toast({
        title: "Error",
        description: "Failed to generate marksheet",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const downloadPDF = () => {
    if (!marksheetData) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const coreSubjects = marksheetData.marks.filter(mark => mark.category === 'Core');
    const additionalSubjects = marksheetData.marks.filter(mark => mark.category !== 'Core');

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Marksheet - ${marksheetData.student.name}</title>
          <style>
            @page { 
              size: A4; 
              margin: 0.4in; 
            }
            @media print {
              body { 
                -webkit-print-color-adjust: exact !important;
                color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
              * {
                -webkit-print-color-adjust: exact !important;
                color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
            }
            body { 
              font-family: 'Arial', sans-serif; 
              margin: 0;
              padding: 0;
              line-height: 1.3;
              font-size: 11px;
              color: #333;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
              min-height: 100vh;
            }
            .marksheet-container {
              background: white !important;
              border-radius: 12px;
              padding: 16px;
              margin: 8px;
              box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
              border: 2px solid #4f46e5 !important;
              max-width: 210mm;
              min-height: 297mm;
            }
            .header { 
              text-align: center; 
              margin-bottom: 16px; 
              position: relative; 
              padding: 12px;
              background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%) !important;
              border-radius: 8px;
              color: white !important;
            }
            .logo { 
              position: absolute; 
              left: 12px; 
              top: 12px; 
              width: 50px; 
              height: 50px; 
              border-radius: 50%;
              border: 2px solid white !important;
              background: white !important;
              padding: 3px;
            }
            .school-info { 
              margin: 0 auto; 
              max-width: 450px; 
            }
            .school-name { 
              font-size: 20px; 
              font-weight: bold; 
              margin: 6px 0; 
              text-shadow: 1px 1px 3px rgba(0,0,0,0.3) !important;
              color: white !important;
            }
            .motto { 
              font-size: 12px; 
              margin: 4px 0; 
              font-style: italic;
              opacity: 0.95;
              color: white !important;
            }
            .address { 
              font-size: 10px; 
              margin: 6px 0; 
              line-height: 1.2; 
              opacity: 0.9;
              color: white !important;
            }
            .marksheet-title { 
              font-size: 16px; 
              font-weight: bold; 
              margin: 10px 0 0 0; 
              background: rgba(255,255,255,0.2) !important;
              padding: 6px;
              border-radius: 6px;
              color: white !important;
            }
            .student-info { 
              margin-bottom: 12px; 
              background: linear-gradient(135deg, #f8faff 0%, #e0e7ff 100%) !important;
              padding: 12px;
              border-radius: 8px;
              border-left: 4px solid #4f46e5 !important;
            }
            .student-info-grid {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 6px;
            }
            .student-info div { 
              margin: 2px 0; 
              font-size: 10px;
            }
            .student-info strong {
              color: #4f46e5 !important;
            }
            table { 
              width: 100%; 
              border-collapse: collapse; 
              margin: 10px 0; 
              font-size: 10px;
              border-radius: 6px;
              overflow: hidden;
              box-shadow: 0 3px 5px rgba(0,0,0,0.08) !important;
            }
            th, td { 
              border: 1px solid #e5e7eb !important; 
              padding: 4px 6px; 
              text-align: left; 
            }
            th { 
              background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%) !important;
              color: white !important;
              font-weight: bold;
              font-size: 9px;
              text-transform: uppercase;
              letter-spacing: 0.3px;
            }
            td {
              background: white !important;
            }
            tr:nth-child(even) td {
              background: #f9fafb !important;
            }
            .summary { 
              margin: 12px 0; 
              background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%) !important;
              padding: 12px;
              border-radius: 8px;
              border-left: 4px solid #10b981 !important;
            }
            .summary-grid {
              display: grid;
              grid-template-columns: 1fr 1fr 1fr;
              gap: 8px;
            }
            .summary div {
              font-size: 10px;
              font-weight: bold;
            }
            .grade { 
              font-weight: bold; 
              padding: 2px 4px;
              border-radius: 3px;
              color: white !important;
              font-size: 9px;
            }
            .grade-A { background: #10b981 !important; }
            .grade-B { background: #3b82f6 !important; }
            .grade-C { background: #f59e0b !important; }
            .grade-D { background: #f97316 !important; }
            .grade-E { background: #ef4444 !important; }
            .section-title { 
              font-weight: bold; 
              margin: 12px 0 6px 0; 
              color: #4f46e5 !important; 
              font-size: 11px;
              padding: 6px;
              background: linear-gradient(135deg, #f0f4ff 0%, #e0e7ff 100%) !important;
              border-radius: 5px;
              border-left: 3px solid #4f46e5 !important;
            }
            .signatures { 
              margin-top: 20px; 
              display: flex; 
              justify-content: space-between; 
              padding: 12px;
              background: linear-gradient(135deg, #fefefe 0%, #f8fafc 100%) !important;
              border-radius: 8px;
            }
            .signature-box { 
              text-align: center; 
              width: 130px; 
            }
            .signature-line { 
              border-bottom: 2px solid #4f46e5 !important; 
              margin-bottom: 4px; 
              height: 25px; 
            }
            .signature-label {
              font-size: 9px;
              font-weight: bold;
              color: #4f46e5 !important;
            }
            .remarks { 
              margin: 12px 0; 
              padding: 10px; 
              background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%) !important;
              border-left: 3px solid #f59e0b !important; 
              border-radius: 6px;
              font-size: 10px;
            }
            .watermark {
              position: fixed;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%) rotate(-45deg);
              font-size: 100px;
              color: rgba(79, 70, 229, 0.04) !important;
              font-weight: bold;
              z-index: -1;
              pointer-events: none;
            }
          </style>
        </head>
        <body>
          <div class="watermark">SELF CONFIDENCE</div>
          <div class="marksheet-container">
            <div class="header">
              <img src="/lovable-uploads/9d302e34-81c8-40fb-b4df-5261a01dbd64.png" alt="Self Confidence Academy Logo" class="logo">
              <div class="school-info">
                <div class="school-name">SELF CONFIDENCE ACADEMY</div>
                <div class="motto">Build Confidence Through Quality Education</div>
                <div class="address">
                  Kamla Nagar, Bakhtal Ki Chowki, M.I.A, Alwar - 301030<br>
                  Rajasthan, India | Phone: 7737595931
                </div>
                <div class="marksheet-title">Academic Report Card - ${marksheetData.summary.academic_year}</div>
              </div>
            </div>
            
            <div class="student-info">
              <div class="student-info-grid">
                <div><strong>Student Name:</strong> ${marksheetData.student.name}</div>
                <div><strong>Father's Name:</strong> ${marksheetData.student.father_name}</div>
                <div><strong>Mother's Name:</strong> ${marksheetData.student.mother_name}</div>
                <div><strong>Date of Birth:</strong> ${formatDate(marksheetData.student.date_of_birth)}</div>
                <div><strong>Class:</strong> ${marksheetData.student.class_name}</div>
                <div><strong>Scholar Number:</strong> ${marksheetData.student.scholar_number}</div>
                <div><strong>Roll Number:</strong> ${marksheetData.student.roll_number}</div>
              </div>
            </div>

            <div class="section-title">📚 Core Subjects</div>
            <table>
              <thead>
                <tr>
                  <th>Subject</th>
                  <th>Max Marks</th>
                  <th>Obtained</th>
                  <th>Percentage</th>
                  <th>Grade</th>
                </tr>
              </thead>
              <tbody>
                ${coreSubjects.map(mark => `
                  <tr>
                    <td>${mark.subject_name}</td>
                    <td>${mark.max_marks}</td>
                    <td>${mark.obtained_marks}</td>
                    <td>${mark.percentage.toFixed(1)}%</td>
                    <td><span class="grade grade-${mark.grade}">${mark.grade}</span></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            ${additionalSubjects.length > 0 ? `
              <div class="section-title">📖 Additional Subjects</div>
              <table>
                <thead>
                  <tr>
                    <th>Subject</th>
                    <th>Max Marks</th>
                    <th>Obtained</th>
                    <th>Percentage</th>
                    <th>Grade</th>
                  </tr>
                </thead>
                <tbody>
                  ${additionalSubjects.map(mark => `
                    <tr>
                      <td>${mark.subject_name}</td>
                      <td>${mark.max_marks}</td>
                      <td>${mark.obtained_marks}</td>
                      <td>${mark.percentage.toFixed(1)}%</td>
                      <td><span class="grade grade-${mark.grade}">${mark.grade}</span></td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            ` : ''}

            <div class="summary">
              <div style="margin-bottom: 8px; font-size: 11px; color: #10b981; font-weight: bold;">
                📊 Academic Summary (Core Subjects)
              </div>
              <div class="summary-grid">
                <div>Total Marks: ${marksheetData.summary.total_marks}/${marksheetData.summary.total_max_marks}</div>
                <div>Percentage: ${marksheetData.summary.overall_percentage.toFixed(2)}%</div>
                <div>Grade: <span class="grade grade-${marksheetData.summary.overall_grade}">${marksheetData.summary.overall_grade}</span></div>
              </div>
            </div>

            <div class="remarks">
              <strong>📝 Remarks:</strong> ${getRemarksByGrade(marksheetData.summary.overall_grade)}
            </div>

            <div class="signatures">
              <div class="signature-box">
                <div class="signature-line"></div>
                <div class="signature-label">Class Teacher</div>
              </div>
              <div class="signature-box">
                <div class="signature-line"></div>
                <div class="signature-label">Principal</div>
              </div>
            </div>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Marksheet Generator</h2>

      <Card>
        <CardHeader>
          <CardTitle>Generate Marksheet</CardTitle>
          <CardDescription>Select student and academic year</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="student">Student</Label>
              <Select
                value={selectedStudent?.id || ""}
                onValueChange={(value) => {
                  const student = students.find(s => s.id === value);
                  setSelectedStudent(student || null);
                  setMarksheetData(null);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select student" />
                </SelectTrigger>
                <SelectContent>
                  {students.map((student) => (
                    <SelectItem key={student.id} value={student.id}>
                      {student.name} - {student.class_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="academic_year">Academic Year</Label>
              <Select value={academicYear} onValueChange={setAcademicYear}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024-25">2024-25</SelectItem>
                  <SelectItem value="2023-24">2023-24</SelectItem>
                  <SelectItem value="2022-23">2022-23</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button onClick={generateMarksheet} disabled={isLoading}>
                <Eye className="h-4 w-4 mr-2" />
                {isLoading ? "Generating..." : "Generate Marksheet"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {marksheetData && (
        <Card className="overflow-hidden">
          <CardHeader className="text-center relative bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <img 
              src="/lovable-uploads/9d302e34-81c8-40fb-b4df-5261a01dbd64.png" 
              alt="Self Confidence Academy Logo" 
              className="absolute left-4 top-4 w-16 h-16 rounded-full border-2 border-white bg-white p-1"
            />
            <div className="mx-auto max-w-2xl">
              <CardTitle className="text-2xl font-bold">Self Confidence Academy</CardTitle>
              <p className="text-lg mt-2 opacity-90">Build Confidence Through Quality Education</p>
              <p className="text-sm mt-2 opacity-80">
                Kamla Nagar, Bakhtal Ki Chowki, M.I.A, Alwar - 301030<br/>
                Rajasthan, India | Phone: 7737595931
              </p>
              <CardDescription className="text-lg mt-4 text-white opacity-90">
                Academic Report Card - {marksheetData.summary.academic_year}
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent className="max-w-4xl mx-auto">
            <div className="space-y-6">
              {/* Student Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border-l-4 border-blue-500">
                <div><strong className="text-blue-700">Student Name:</strong> {marksheetData.student.name}</div>
                <div><strong className="text-blue-700">Father's Name:</strong> {marksheetData.student.father_name}</div>
                <div><strong className="text-blue-700">Mother's Name:</strong> {marksheetData.student.mother_name}</div>
                <div><strong className="text-blue-700">Date of Birth:</strong> {formatDate(marksheetData.student.date_of_birth)}</div>
                <div><strong className="text-blue-700">Class:</strong> {marksheetData.student.class_name}</div>
                <div><strong className="text-blue-700">Scholar Number:</strong> {marksheetData.student.scholar_number}</div>
                <div><strong className="text-blue-700">Roll Number:</strong> {marksheetData.student.roll_number}</div>
              </div>

              {/* Core Subjects Table */}
              <div>
                <h3 className="text-lg font-semibold mb-3 text-blue-800 bg-blue-50 p-3 rounded-lg border-l-4 border-blue-500">
                  📚 Core Subjects
                </h3>
                <Table className="border rounded-lg overflow-hidden">
                  <TableHeader>
                    <TableRow className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                      <TableHead className="text-white font-semibold">Subject</TableHead>
                      <TableHead className="text-white font-semibold">Max Marks</TableHead>
                      <TableHead className="text-white font-semibold">Marks Obtained</TableHead>
                      <TableHead className="text-white font-semibold">Percentage</TableHead>
                      <TableHead className="text-white font-semibold">Grade</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {marksheetData.marks.filter(mark => mark.category === 'Core').map((mark, index) => (
                      <TableRow key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                        <TableCell className="font-medium">{mark.subject_name}</TableCell>
                        <TableCell>{mark.max_marks}</TableCell>
                        <TableCell>{mark.obtained_marks}</TableCell>
                        <TableCell>{mark.percentage.toFixed(2)}%</TableCell>
                        <TableCell>
                          <span className={`px-3 py-1 rounded-full text-white text-sm font-semibold ${
                            mark.grade === 'A' ? 'bg-green-500' :
                            mark.grade === 'B' ? 'bg-blue-500' :
                            mark.grade === 'C' ? 'bg-yellow-500' :
                            mark.grade === 'D' ? 'bg-orange-500' : 'bg-red-500'
                          }`}>
                            {mark.grade}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Additional Subjects Table */}
              {marksheetData.marks.filter(mark => mark.category !== 'Core').length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-purple-800 bg-purple-50 p-3 rounded-lg border-l-4 border-purple-500">
                    📖 Additional Subjects
                  </h3>
                  <Table className="border rounded-lg overflow-hidden">
                    <TableHeader>
                      <TableRow className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                        <TableHead className="text-white font-semibold">Subject</TableHead>
                        <TableHead className="text-white font-semibold">Max Marks</TableHead>
                        <TableHead className="text-white font-semibold">Marks Obtained</TableHead>
                        <TableHead className="text-white font-semibold">Percentage</TableHead>
                        <TableHead className="text-white font-semibold">Grade</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {marksheetData.marks.filter(mark => mark.category !== 'Core').map((mark, index) => (
                        <TableRow key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                          <TableCell className="font-medium">{mark.subject_name}</TableCell>
                          <TableCell>{mark.max_marks}</TableCell>
                          <TableCell>{mark.obtained_marks}</TableCell>
                          <TableCell>{mark.percentage.toFixed(2)}%</TableCell>
                          <TableCell>
                            <span className={`px-3 py-1 rounded-full text-white text-sm font-semibold ${
                              mark.grade === 'A' ? 'bg-green-500' :
                              mark.grade === 'B' ? 'bg-blue-500' :
                              mark.grade === 'C' ? 'bg-yellow-500' :
                              mark.grade === 'D' ? 'bg-orange-500' : 'bg-red-500'
                            }`}>
                              {mark.grade}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {/* Summary */}
              <div className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border-l-4 border-green-500">
                <h3 className="text-lg font-semibold mb-4 text-green-800">📊 Academic Summary (Core Subjects Only)</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                    <div className="text-2xl font-bold text-gray-800">{marksheetData.summary.total_marks}/{marksheetData.summary.total_max_marks}</div>
                    <div className="text-sm text-gray-600">Total Marks</div>
                  </div>
                  <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                    <div className="text-2xl font-bold text-blue-600">{marksheetData.summary.overall_percentage.toFixed(2)}%</div>
                    <div className="text-sm text-gray-600">Overall Percentage</div>
                  </div>
                  <div className="text-center p-3 bg-white rounded-lg shadow-sm">
                    <span className={`text-2xl font-bold px-4 py-2 rounded-full text-white ${
                      marksheetData.summary.overall_grade === 'A' ? 'bg-green-500' :
                      marksheetData.summary.overall_grade === 'B' ? 'bg-blue-500' :
                      marksheetData.summary.overall_grade === 'C' ? 'bg-yellow-500' :
                      marksheetData.summary.overall_grade === 'D' ? 'bg-orange-500' : 'bg-red-500'
                    }`}>
                      {marksheetData.summary.overall_grade}
                    </span>
                    <div className="text-sm text-gray-600 mt-2">Overall Grade</div>
                  </div>
                </div>
              </div>

              {/* Remarks */}
              <div className="p-4 bg-gradient-to-r from-yellow-50 to-amber-50 rounded-lg border-l-4 border-yellow-500">
                <div className="font-semibold text-yellow-800">📝 Remarks:</div>
                <div className="text-yellow-700 mt-1">{getRemarksByGrade(marksheetData.summary.overall_grade)}</div>
              </div>

              {/* Signature Section */}
              <div className="flex justify-between mt-8 pt-8 bg-gradient-to-r from-gray-50 to-slate-50 p-6 rounded-lg">
                <div className="text-center">
                  <div className="border-b-2 border-blue-500 w-48 h-12 mb-3"></div>
                  <div className="font-semibold text-blue-700">Class Teacher</div>
                </div>
                <div className="text-center">
                  <div className="border-b-2 border-blue-500 w-48 h-12 mb-3"></div>
                  <div className="font-semibold text-blue-700">Principal</div>
                </div>
              </div>

              <Button onClick={downloadPDF} className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-lg py-3">
                <Download className="h-5 w-5 mr-2" />
                Download PDF Marksheet
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MarksheetGenerator;
