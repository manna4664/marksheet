
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Save, Edit, Users } from "lucide-react";

interface Student {
  id: string;
  name: string;
  class_name: string;
  scholar_number: string;
  roll_number: string;
}

interface Subject {
  id: string;
  name: string;
  max_marks: number;
  category: string;
}

interface Mark {
  subject: string;
  marks_obtained: number;
  max_marks: number;
  grade: string;
}

const MarksEntry = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [classStudents, setClassStudents] = useState<Student[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [marks, setMarks] = useState<Mark[]>([]);
  const [academicYear, setAcademicYear] = useState("2024-25");
  const [isEditMode, setIsEditMode] = useState(false);
  const [availableClasses, setAvailableClasses] = useState<string[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    fetchStudents();
  }, []);

  useEffect(() => {
    if (selectedStudent) {
      fetchSubjects(selectedStudent.class_name);
      fetchExistingMarks(selectedStudent.id);
    }
  }, [selectedStudent, academicYear]);

  useEffect(() => {
    if (selectedClass) {
      const filteredStudents = students.filter(student => student.class_name === selectedClass);
      setClassStudents(filteredStudents);
      setSelectedStudent(null);
      setMarks([]);
    }
  }, [selectedClass, students]);

  const fetchStudents = async () => {
    try {
      const { data, error } = await supabase
        .from("students")
        .select("*")
        .order("class_name", { ascending: true });

      if (error) throw error;
      
      const studentsData = data || [];
      setStudents(studentsData);
      
      // Extract unique classes
      const classes = [...new Set(studentsData.map(student => student.class_name))].sort();
      setAvailableClasses(classes);
      
      console.log("Fetched students:", studentsData.length);
      console.log("Available classes:", classes);
    } catch (error) {
      console.error("Error fetching students:", error);
      toast({
        title: "Error",
        description: "Failed to fetch students",
        variant: "destructive",
      });
    }
  };

  const fetchSubjects = async (className: string) => {
    try {
      console.log("Fetching subjects for class:", className);
      
      const { data, error } = await supabase
        .from("subjects")
        .select("*")
        .eq("class_level", className)
        .order("category", { ascending: true });

      if (error) throw error;
      
      console.log("Fetched subjects:", data);
      setSubjects(data || []);
      
      // Initialize marks array with correct structure
      if (data && data.length > 0) {
        const initialMarks = data.map(subject => ({
          subject: subject.name,
          marks_obtained: 0,
          max_marks: subject.max_marks,
          grade: "E"
        }));
        setMarks(initialMarks);
        console.log("Initialized marks:", initialMarks);
      }
    } catch (error) {
      console.error("Error fetching subjects:", error);
      toast({
        title: "Error",
        description: "Failed to fetch subjects",
        variant: "destructive",
      });
    }
  };

  const fetchExistingMarks = async (studentId: string) => {
    try {
      console.log("Fetching existing marks for student:", studentId);
      
      const { data, error } = await supabase
        .from("marks")
        .select("*")
        .eq("student_id", studentId)
        .eq("academic_year", academicYear);

      if (error) throw error;
      
      console.log("Existing marks data:", data);
      
      if (data && data.length > 0) {
        // Update marks array with existing data
        setMarks(prevMarks => {
          return prevMarks.map(mark => {
            const existingMark = data.find(existing => existing.subject === mark.subject);
            if (existingMark) {
              return {
                subject: mark.subject,
                marks_obtained: existingMark.marks_obtained,
                max_marks: mark.max_marks,
                grade: existingMark.grade
              };
            }
            return mark;
          });
        });
        setIsEditMode(true);
        console.log("Found existing marks, switched to edit mode");
      } else {
        setIsEditMode(false);
        console.log("No existing marks found");
      }
    } catch (error) {
      console.error("Error fetching existing marks:", error);
    }
  };

  const calculateGrade = (obtained: number, max: number): string => {
    if (max === 0) return "E";
    const percentage = (obtained / max) * 100;
    if (percentage >= 86) return "A";
    if (percentage >= 71) return "B";
    if (percentage >= 51) return "C";
    if (percentage >= 31) return "D";
    return "E";
  };

  const handleMarksChange = (index: number, value: string) => {
    const marksObtained = parseInt(value) || 0;
    const maxMarks = marks[index]?.max_marks || 0;
    
    console.log(`Updating marks for index ${index}: ${marksObtained}/${maxMarks}`);
    
    // Validation: Check if obtained marks exceed max marks
    if (marksObtained > maxMarks) {
      toast({
        title: "Invalid Marks",
        description: `Obtained marks (${marksObtained}) cannot be greater than maximum marks (${maxMarks})`,
        variant: "destructive",
      });
      return;
    }
    
    const updatedMarks = [...marks];
    updatedMarks[index] = {
      ...updatedMarks[index],
      marks_obtained: marksObtained,
      grade: calculateGrade(marksObtained, maxMarks)
    };
    setMarks(updatedMarks);
    console.log("Updated marks:", updatedMarks[index]);
  };

  const handleSaveMarks = async () => {
    if (!selectedStudent) {
      toast({
        title: "Error",
        description: "Please select a student",
        variant: "destructive",
      });
      return;
    }

    if (marks.length === 0) {
      toast({
        title: "Error",
        description: "No marks to save",
        variant: "destructive",
      });
      return;
    }

    try {
      console.log("Saving marks for student:", selectedStudent.id);
      console.log("Marks to save:", marks);

      // Delete existing marks for this student and academic year
      const { error: deleteError } = await supabase
        .from("marks")
        .delete()
        .eq("student_id", selectedStudent.id)
        .eq("academic_year", academicYear);

      if (deleteError) {
        console.error("Error deleting existing marks:", deleteError);
        throw deleteError;
      }

      // Insert new marks
      const marksToInsert = marks.map(mark => ({
        student_id: selectedStudent.id,
        subject: mark.subject,
        marks_obtained: mark.marks_obtained,
        max_marks: mark.max_marks,
        grade: mark.grade,
        academic_year: academicYear
      }));

      console.log("Inserting marks:", marksToInsert);

      const { error: insertError } = await supabase
        .from("marks")
        .insert(marksToInsert);

      if (insertError) {
        console.error("Error inserting marks:", insertError);
        throw insertError;
      }

      toast({
        title: "Success",
        description: "Marks saved successfully",
      });
      setIsEditMode(true);
      console.log("Marks saved successfully");
    } catch (error) {
      console.error("Error saving marks:", error);
      toast({
        title: "Error",
        description: "Failed to save marks. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Marks Entry</h2>

      {/* Class Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Select Class
          </CardTitle>
          <CardDescription>Choose a class to view students</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="class">Class</Label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {availableClasses.map((className) => (
                    <SelectItem key={className} value={className}>
                      Class {className}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="academic_year">Academic Year</Label>
              <Select value={academicYear} onValueChange={setAcademicYear}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024-25">2024-25</SelectItem>
                  <SelectItem value="2023-24">2023-24</SelectItem>
                  <SelectItem value="2022-23">2022-23</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Student Selection */}
      {selectedClass && classStudents.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Select Student from Class {selectedClass}</CardTitle>
            <CardDescription>{classStudents.length} students found</CardDescription>
          </CardHeader>
          <CardContent>
            <div>
              <Label htmlFor="student">Student</Label>
              <Select
                value={selectedStudent?.id || ""}
                onValueChange={(value) => {
                  const student = classStudents.find(s => s.id === value);
                  setSelectedStudent(student || null);
                  console.log("Selected student:", student);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select student" />
                </SelectTrigger>
                <SelectContent>
                  {classStudents.map((student) => (
                    <SelectItem key={student.id} value={student.id}>
                      {student.name} (Roll: {student.roll_number}) - Scholar: {student.scholar_number}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Marks Entry Table */}
      {selectedStudent && subjects.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{isEditMode ? 'Edit' : 'Enter'} Marks for {selectedStudent.name}</span>
              {isEditMode && (
                <div className="flex items-center gap-2 text-sm text-blue-600">
                  <Edit className="h-4 w-4" />
                  Edit Mode
                </div>
              )}
            </CardTitle>
            <CardDescription>Class: {selectedStudent.class_name} | Roll: {selectedStudent.roll_number}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Subject</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Max Marks</TableHead>
                    <TableHead>Marks Obtained</TableHead>
                    <TableHead>Grade</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {subjects.map((subject, index) => {
                    const mark = marks.find(m => m.subject === subject.name) || {
                      subject: subject.name,
                      marks_obtained: 0,
                      max_marks: subject.max_marks,
                      grade: "E"
                    };
                    return (
                      <TableRow key={subject.id}>
                        <TableCell className="font-medium">{subject.name}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            subject.category === 'Core' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                          }`}>
                            {subject.category}
                          </span>
                        </TableCell>
                        <TableCell className="font-medium">{subject.max_marks}</TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min="0"
                            max={subject.max_marks}
                            value={mark.marks_obtained}
                            onChange={(e) => handleMarksChange(index, e.target.value)}
                            className="w-24"
                            placeholder="0"
                          />
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-white text-xs font-semibold ${
                            mark.grade === 'A' ? 'bg-green-500' :
                            mark.grade === 'B' ? 'bg-blue-500' :
                            mark.grade === 'C' ? 'bg-yellow-500' :
                            mark.grade === 'D' ? 'bg-orange-500' : 'bg-red-500'
                          }`}>
                            {mark.grade}
                          </span>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              
              <Button onClick={handleSaveMarks} className="w-full" size="lg">
                <Save className="h-4 w-4 mr-2" />
                {isEditMode ? 'Update Marks' : 'Save Marks'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* No students message */}
      {selectedClass && classStudents.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-gray-500">No students found in Class {selectedClass}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MarksEntry;
